#!/bin/bash

cd /usr/share/zaproxy/ && ./zap.sh
