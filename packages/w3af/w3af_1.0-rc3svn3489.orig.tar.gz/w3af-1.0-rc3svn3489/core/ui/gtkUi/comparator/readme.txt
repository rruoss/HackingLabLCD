These .py and pixmaps were took from the MELD project...

    http://meld.sourceforge.net/
    copyright (C) 2002-2006 Stephen Kennedy <stevek@gnome.org>

..., heavily trimmed by me to be able to compare two texts from any 
PyGTK application, without needing more than the visual comparation.

All the nice things that this do now are from the original project, all
the ugly stuff that is left is my responsibility, :)

    Facundo Batista
    facundo@taniquetil.com.ar
