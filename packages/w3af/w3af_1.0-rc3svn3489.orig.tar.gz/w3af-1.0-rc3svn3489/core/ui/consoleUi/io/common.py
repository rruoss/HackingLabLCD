
KEY_UP    = '\x1B[A'
KEY_DOWN  = '\x1B[B'
KEY_RIGHT = '\x1B[C'
KEY_LEFT  = '\x1B[D'

KEY_HOME  = '^A'
KEY_END   = '^E'

KEY_BACKSPACE = '\x7F'
