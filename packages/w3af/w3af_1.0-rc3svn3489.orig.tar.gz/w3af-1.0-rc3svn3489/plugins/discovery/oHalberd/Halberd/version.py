##
##  ./Halberd/version.py -- Version Information for halberd (syntax: Python)
##  [automatically generated and maintained by GNU shtool]
##

class version:
    v_hex       = 0x002203
    v_short     = "0.2.3"
    v_long      = "0.2.3 (18-Jul-2007)"
    v_tex       = "This is halberd, Version 0.2.3 (18-Jul-2007)"
    v_gnu       = "halberd 0.2.3 (18-Jul-2007)"
    v_web       = "halberd/0.2.3"
    v_sccs      = "@(#)halberd 0.2.3 (18-Jul-2007)"
    v_rcs       = "$Id: halberd 0.2.3 (18-Jul-2007) $"

