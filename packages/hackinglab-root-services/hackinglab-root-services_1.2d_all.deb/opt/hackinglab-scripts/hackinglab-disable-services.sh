update-rc.d squid disable
update-rc.d postgresql disable
