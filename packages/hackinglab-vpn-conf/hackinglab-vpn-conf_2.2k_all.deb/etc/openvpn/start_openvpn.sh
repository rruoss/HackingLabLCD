# Start VPN in terminal as root (debugging purpose)
/usr/sbin/openvpn --cd /etc/openvpn --script-security 2 --config /etc/openvpn/HackingLab.ovpn
