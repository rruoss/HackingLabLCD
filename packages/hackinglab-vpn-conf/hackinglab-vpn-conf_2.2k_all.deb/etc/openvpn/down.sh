#!/bin/bash
mv -f /etc/resolv.conf.old /etc/resolv.conf
chmod 644 /etc/resolv.conf
