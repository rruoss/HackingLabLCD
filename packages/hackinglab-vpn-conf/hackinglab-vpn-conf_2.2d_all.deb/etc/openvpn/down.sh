#!/bin/bash
mv -f /etc/resolv.conf.old /etc/resolv.conf
chown 777 /etc/resolv.conf
