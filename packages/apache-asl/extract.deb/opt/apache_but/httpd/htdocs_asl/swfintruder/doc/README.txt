SWFIntruder 0.9

Author: Stefano Di Paola 
Email: stefano.dipaola at mindedsecurity.com

Copyright 2007

License GPL 2.0

----------------------------

Just save the SWFIntruder root directory to you webserver and
point you browser to it and click 'Help' menu.


Recommended Configuration

   1. Firefox 2.x [Needed]
   2. FireBug Addon
   3. Flash Player Plugin Ver >= 9 [Needed]
   4. Any Web Server [Needed]

