var ax_name = 'CLSID';
ax[ax_name] = new Array();
ax[ax_name]['Info'] = '{0000031A-0000-0000-C000-000000000046}';
ax[ax_name]['NotSafe'] = true;
ax[ax_name]['IDispatchFailed'] = true;
