// ---===[ AxMan (c) 2006 hdm[at]metasploit.com - All rights reserved.

/*
 *
 * Object Blacklists (aka Bug List)
 *
 */
 
 
var blclasses = new Array(

// Example class blacklist
//	'{3050f819-98b5-11cf-bb82-00aa00bdce0b}'

);

/* Example Property Blacklists

blproperties["{3050f819-98b5-11cf-bb82-00aa00bdce0b}"] = new Array(
	'fonts',
	'BlockFormats'
);

*/

/* Example Method Blacklists

blmethods["{844F4806-E8A8-11d2-9652-00C04FC30871}"] = new Array(
	'setSlice' // (0x7ffffffe, 0, 0x01020304, 0) [exploitable]
);

*/
