var ax_name = 'Component';
ax[ax_name] = new Array();
ax[ax_name]['NotSafe'] = true;
ax[ax_name]['IDispatchFailed'] = true;
